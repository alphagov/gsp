# -*- coding: utf-8 -*-
from dateparser.data import date_translation_data, numeral_translation_data
from .languages_info import language_order, language_locale_dict