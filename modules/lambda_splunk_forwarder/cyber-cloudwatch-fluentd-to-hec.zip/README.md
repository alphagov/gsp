# Cloudwatch to Splunk HEC

## Deploying as a Lambda

You'll need to zip up this repo--you can do something like this to zip the
contents without git stuff:

```sh
zip -r ../cyber-cloudwatch-fluentd-to-hec.zip . --exclude ./\.git/\*
```
