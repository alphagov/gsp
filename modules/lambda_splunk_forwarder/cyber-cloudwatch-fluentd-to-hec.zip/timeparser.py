import json
import re


HSM_TIME_REGEX = r'Time\s*: (?P<timestamp>[^,]*),'


def extract_time(message):
    res = False
    match = re.search(HSM_TIME_REGEX, message)
    if match:
        res = match.group(1)
    return res
